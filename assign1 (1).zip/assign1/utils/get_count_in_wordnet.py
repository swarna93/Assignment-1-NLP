from nltk.corpus import wordnet as wn
def gcount():
	c = 0
	for w in wn.words():
		c += 1
	return c
